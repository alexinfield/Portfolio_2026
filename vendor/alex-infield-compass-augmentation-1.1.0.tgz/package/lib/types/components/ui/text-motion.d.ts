export type TextMotionVariant = "count" | "rolling" | "typewriter" | "stagger" | "reveal" | "blur-reveal" | "fade" | "rotate" | "scramble" | "marquee" | "highlight";
export declare const motionProgress: (value: number) => number;
export declare const motionEase: (value: number) => number;
export declare function motionNumber(from: number, to: number, progress: number): number;
export declare function scrambleText(text: string, progress: number): string;
export declare function textRevealParts(text: string, by?: "word" | "char", locale?: string): {
    text: string;
    pieces: {
        text: string;
        index: number;
    }[];
}[];
export declare function textRevealProgress(elapsed: number, index: number, duration?: number, stagger?: number, delay?: number): number;
export declare function TextMotion({ variant, text, phrases, from, to, duration, by, stagger, delay, paused, locale, formatNumber, decoration, className, }: {
    variant: TextMotionVariant;
    text?: string;
    phrases?: string[];
    from?: number;
    to?: number;
    duration?: number;
    by?: "word" | "char";
    stagger?: number;
    delay?: number;
    paused?: boolean;
    locale?: string;
    formatNumber?: (value: number) => string;
    decoration?: "highlight" | "underline";
    className?: string;
}): import("react").JSX.Element;

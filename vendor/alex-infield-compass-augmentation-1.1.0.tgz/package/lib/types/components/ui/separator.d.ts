import type { ComponentProps } from "react";
import { Separator as SeparatorPrimitive } from "radix-ui";
export declare function Separator({ className, orientation, decorative, ...props }: ComponentProps<typeof SeparatorPrimitive.Root>): import("react").JSX.Element;

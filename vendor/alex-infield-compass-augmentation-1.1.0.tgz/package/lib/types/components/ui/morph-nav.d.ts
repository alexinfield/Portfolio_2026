import * as React from "react";
export type MorphNavLink = {
    label: string;
    description?: string;
    href?: string;
    icon?: React.ReactNode;
};
export type MorphNavItem = {
    value: string;
    label: string;
    href?: string;
    links?: MorphNavLink[];
};
export type MorphNavProps = {
    brand?: {
        name: string;
        mark?: React.ReactNode;
        href?: string;
    };
    items: MorphNavItem[];
    current?: string;
    compact?: boolean;
    search?: {
        label?: string;
        placeholder?: string;
        emptyLabel?: string;
        items: MorphNavLink[];
    };
    action?: {
        label: string;
        href?: string;
        onClick?: () => void;
    };
    onNavigate?: (destination: MorphNavLink) => void;
    label?: string;
    menuLabel?: string;
    closeLabel?: string;
    className?: string;
};
export declare function MorphNav({ brand, items, current, compact, search, action, onNavigate, label, menuLabel, closeLabel, className }: MorphNavProps): React.JSX.Element;

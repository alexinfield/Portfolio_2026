import * as React from "react";
export declare function Textarea({ className, ...props }: React.ComponentProps<"textarea">): React.JSX.Element;

import * as React from "react";
export type StampStickersProps = {
    label?: string;
    className?: string;
    spriteSrc?: string;
    maxStamps?: number;
    onStamp?: (city: string) => void;
};
/** A click surface that collects small city stamps like luggage stickers. */
export declare function StampStickers({ label, className, spriteSrc, maxStamps, onStamp }: StampStickersProps): React.JSX.Element;

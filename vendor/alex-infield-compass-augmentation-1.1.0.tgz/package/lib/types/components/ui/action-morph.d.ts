import * as React from "react";
export type ActionMorphAction = {
    id: string;
    label: string;
    description?: string;
    icon: React.ReactNode;
    shortcut?: string;
    composer: {
        title: string;
        placeholder?: string;
        multiline?: boolean;
        choices?: {
            label: string;
            options: string[];
        };
        submitLabel: string;
        emptyHint?: string;
    };
};
export type ActionMorphSubmission = {
    action: string;
    text: string;
    choice?: string;
};
export type ActionMorphProps = {
    actions: ActionMorphAction[];
    expansionOnly?: boolean;
    label?: string;
    closeLabel?: string;
    backLabel?: string;
    errorLabel?: string;
    emptyLabel?: string;
    corner?: "start" | "end";
    resetAfter?: number;
    onSubmit: (submission: ActionMorphSubmission) => void | Promise<unknown>;
    className?: string;
};
export declare function ActionMorph({ actions, expansionOnly, label, closeLabel, backLabel, errorLabel, emptyLabel, corner, resetAfter, onSubmit, className }: ActionMorphProps): React.JSX.Element;

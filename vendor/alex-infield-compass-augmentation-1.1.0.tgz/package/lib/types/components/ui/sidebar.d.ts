import * as React from "react";
type SidebarState = {
    collapsed: boolean;
    previewing: boolean;
    setCollapsed: (collapsed: boolean) => void;
    expandOnHover: boolean;
    setHovered: (hovered: boolean) => void;
    compact: boolean;
    mobileOpen: boolean;
    setMobileOpen: (open: boolean) => void;
    toggle: () => void;
    id: string;
};
export declare function useSidebar(): SidebarState;
export declare function SidebarProvider({ children, className, compactMode, expandOnHover, ...props }: React.ComponentProps<"div"> & {
    compactMode?: "sheet" | "rail" | "static";
    expandOnHover?: boolean;
}): React.JSX.Element;
export declare function Sidebar({ children, label, className }: {
    children: React.ReactNode;
    label?: string;
    className?: string;
}): React.JSX.Element;
export declare function SidebarHeader({ className, ...props }: React.ComponentProps<"div">): React.JSX.Element;
export declare function SidebarContent({ className, ...props }: React.ComponentProps<"div">): React.JSX.Element;
export declare function SidebarFooter({ className, ...props }: React.ComponentProps<"div">): React.JSX.Element;
export declare function SidebarGroup({ label, children }: {
    label: string;
    children: React.ReactNode;
}): React.JSX.Element;
export declare function SidebarMenuButton({ active, icon: Icon, children, className, onClick, label, asChild, ...props }: React.ComponentProps<"button"> & {
    active?: boolean;
    icon?: React.ComponentType<{
        className?: string;
        "aria-hidden"?: boolean;
    }>;
    label: string;
    asChild?: boolean;
}): React.JSX.Element;
export declare function SidebarTrigger({ label, appearance }: {
    label?: string;
    appearance?: "default" | "plain";
}): React.JSX.Element;
export {};

import * as React from "react";
export type GlassTabBarItem = {
    value: string;
    label: string;
    icon: React.ReactNode;
    badge?: number;
    disabled?: boolean;
};
export type GlassTabBarProps = {
    items: GlassTabBarItem[];
    value?: string;
    defaultValue?: string;
    onValueChange?: (value: string) => void;
    compact?: boolean;
    compactOnScroll?: boolean;
    scrollRef?: React.RefObject<HTMLElement | null>;
    className?: string;
    "aria-label"?: string;
};
/** Floating primary navigation. Supply the selected section through value. */
export declare function GlassTabBar({ items, value, defaultValue, onValueChange, compact, compactOnScroll, scrollRef, className, "aria-label": label }: GlassTabBarProps): React.JSX.Element;

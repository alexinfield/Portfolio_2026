import * as React from "react";
export type DataFlowNode = {
    id: string;
    label: string;
    meta?: string;
    detail?: string;
    icon?: React.ReactNode;
    share?: number;
};
export type DataFlowProps = {
    sources: DataFlowNode[];
    destinations: DataFlowNode[];
    core?: {
        label: string;
        icon?: React.ReactNode;
        countLabel?: string;
    };
    processedCount?: number;
    speed?: number;
    paused?: boolean;
    label?: string;
    caption?: React.ReactNode;
    className?: string;
    onRecordProcessed?: () => void;
};
export declare function DataFlow({ sources, destinations, core, processedCount, speed, paused, label, caption, className, onRecordProcessed }: DataFlowProps): React.JSX.Element;

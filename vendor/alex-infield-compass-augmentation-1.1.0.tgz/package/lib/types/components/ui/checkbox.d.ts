import * as React from "react";
import { Checkbox as CheckboxPrimitive } from "radix-ui";
declare function SelectionLabel({ className, ...props }: React.ComponentProps<"label">): React.JSX.Element;
declare function Checkbox({ className, ...props }: React.ComponentProps<typeof CheckboxPrimitive.Root>): React.JSX.Element;
export { Checkbox, SelectionLabel };

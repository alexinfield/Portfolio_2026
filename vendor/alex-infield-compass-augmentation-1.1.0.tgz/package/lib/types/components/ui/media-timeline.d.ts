export declare function MediaTimeline({ start, end, position, onRangeChange, onPositionChange }: {
    start: number;
    end: number;
    position: number;
    onRangeChange: (range: number[]) => void;
    onPositionChange: (position: number) => void;
}): import("react").JSX.Element;

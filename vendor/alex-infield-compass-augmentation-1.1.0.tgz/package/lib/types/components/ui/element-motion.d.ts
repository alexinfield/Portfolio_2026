import { type ReactNode } from "react";
import { type TargetAndTransition } from "motion/react";
export type ElementMotionVariant = "fade" | "slide" | "scale" | "pop" | "mask" | "blur" | "bounce";
export declare const dataInspectionMotion: {
    readonly dimmedOpacity: 0.28;
    readonly feedbackDuration: 0.14;
    readonly enterDuration: 0.18;
    readonly exitDuration: 0.1;
    readonly enterDistance: 4;
    readonly rowStagger: 0.018;
    readonly maxStagger: 0.18;
    readonly spring: {
        readonly type: "spring";
        readonly stiffness: 500;
        readonly damping: 40;
        readonly mass: 0.7;
    };
};
export declare function dataInspectionOpacity(active: readonly [number, number] | null, row: number, column: number): 1 | 0.28;
export declare function dataInspectionDelay(index: number, reduced?: boolean): number;
export declare function dataInspectionPosition(anchor: {
    x: number;
    y: number;
    width: number;
    height: number;
}, bounds: {
    width: number;
    height: number;
}, panel?: {
    width: number;
    height: number;
}): {
    x: number;
    y: number;
};
export declare function DataInspectionPanel({ id, point, width, children }: {
    id: string;
    point: {
        x: number;
        y: number;
    };
    width?: number;
    children: ReactNode;
}): import("react").JSX.Element;
export declare function elementMotionStates(variant: ElementMotionVariant, reduced?: boolean): {
    initial: TargetAndTransition;
    animate: TargetAndTransition;
    exit: TargetAndTransition;
} | {
    initial: {
        opacity: number;
    };
    animate: {
        opacity: number;
    };
    exit: {
        opacity: number;
    };
};
export declare function ElementMotion({ variant, visible, children, className, onExitComplete, onAnimationComplete, }: {
    variant: ElementMotionVariant;
    visible?: boolean;
    children: ReactNode;
    className?: string;
    onExitComplete?: () => void;
    onAnimationComplete?: () => void;
}): import("react").JSX.Element;

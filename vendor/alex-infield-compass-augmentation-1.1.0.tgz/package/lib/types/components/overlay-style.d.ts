import { type CSSProperties, type ReactNode } from "react";
export declare function OverlayStyleProvider({ style, children }: {
    style: CSSProperties;
    children: ReactNode;
}): import("react").JSX.Element;
export declare function useOverlayStyle(style?: CSSProperties): CSSProperties | undefined;

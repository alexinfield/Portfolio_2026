# Upstream COMPASS payloads

Original registry downloads are retained unchanged, with source URLs/SHA-256 in each `sources.json`.

- `1.0.15/` — current and approved through augmentation 1.1.0, October 27, 2026. `adoption-lock.json` records every upstream/adopted file hash.
- `1.0.0/` — previous approved kit, retained unchanged. `alex-infield-compass-augmentation-1.0.0-source.tgz` is the complete augmentation source/build-input checkpoint for rollback; it is distinct from the original vendor downloads.
- `0.1.0/` — initial install and transport-correction history, unchanged.
- `shadcn-css-source.json` — identity of the retained 4.21.0 variant CSS.

`npm run verify:source` checks original hashes, the counted adoption and emitted CSS-variable closure. The consumer TGZ includes only compiled runtime/declarations, licences/docs and the compact current provenance manifests; raw payloads and editable source stay in this shared workspace. Build only from a host-local copy.

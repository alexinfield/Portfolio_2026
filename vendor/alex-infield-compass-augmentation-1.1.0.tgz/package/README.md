# Alex design system + COMPASS 1.0.15

**Current and approved: `@alex-infield/compass-augmentation@1.1.0`, built on COMPASS 1.0.15. Alex approved it in T3 on October 27, 2026 after independent re-review as the current kit of his design system; use it for new work and deliberate app upgrades.** Alex's tokens, Funktional Grotesk, R05 geometry, grayscale and borderless direction control the look; COMPASS supplies the React components and behaviour. Dark is the default appearance; light and system are available.

## Install (web, React 19.2.6 or later)

1. Add the closed package from this folder to the app: `npm install "<path>/alex-infield-compass-augmentation-1.1.0.tgz"` (copy the TGZ next to the app if it builds on another host). No Tailwind is needed in the app.
2. Import the stylesheet once, before the app's own CSS: `import "@alex-infield/compass-augmentation/styles.css";`
3. Wrap the app once:
   - no theme yet: `<DesignSystemProvider>`, which is dark by default and remembers Light / Dark / System (see the next section for the whole page);
   - app already owns appearance: `<DesignSystemBoundary theme={resolved}>`.
   Everything COMPASS opens (dialogs, sheets, menus, tooltips, chart tooltips) stays inside that boundary.
4. Import components from the root, and the heavier families from subpaths: `/chart` (charts), `/date` (calendar, date range, time), `/motion`, `/playful` (optional, decorative), and `/blocks` (optional navigation and flow blocks).

Fonts are not in the package; the app loads Funktional Grotesk itself (Alex's font files: `../public/fonts/`). Keep using an app's accepted Alex components (R05/R7 button, field, navigation, status) where it has them.

## Whole page dark by default, with Light / Dark / System

Alex's standing preference (Style Guide decision D13): open dark, offer Light, Dark and System, remember the choice per device.

1. **Tokens for the page itself.** The package stylesheet styles only what is inside the boundary and carries its own copy of Alex's values. For the app's own CSS and the page background, import Alex's token file once: `261014 Component Suite/Code/src/tokens.css` (light and dark values keyed on `data-theme`, plus the Funktional Grotesk `@font-face`; copy the font files from `Code/public/fonts/` and fix the paths). Then set `html, body { background: var(--canvas); color: var(--text); }`.
2. **Dark before the first paint.** Put `<html class="dark" data-theme="dark" style="color-scheme: dark">` in the app's `index.html`.
3. **Provider.** Wrap the app once in `<DesignSystemProvider>`. It starts dark, stores the choice under `alex-design-theme`, and keeps `class` and `data-theme` on `<html>` in step, so the page tokens, the browser chrome and every COMPASS component switch together.
4. **Switcher.** Use a segmented control, in settings or a toolbar:

```tsx
import {useTheme, ToggleGroup, ToggleGroupItem} from "@alex-infield/compass-augmentation";

function AppearanceControl() {
  const {theme, setTheme} = useTheme();
  return <ToggleGroup type="single" spacing={0} aria-label="Appearance"
    value={theme ?? "dark"} onValueChange={value => value && setTheme(value)}>
    <ToggleGroupItem value="light">Light</ToggleGroupItem>
    <ToggleGroupItem value="dark">Dark</ToggleGroupItem>
    <ToggleGroupItem value="system">System</ToggleGroupItem>
  </ToggleGroup>;
}
```

For a single on/off row in an iOS-style settings list, use `<Switch checked={resolvedTheme === "dark"} onCheckedChange={on => setTheme(on ? "dark" : "light")} aria-label="Dark appearance" />` (both values come from `useTheme()`), and offer System separately. If the app already stores appearance itself, skip the provider. Pass the resolved value to `<DesignSystemBoundary theme={...}>` and set `class` and `data-theme` on `<html>` yourself.

## What is in it

- **Core** (root): button, card, input, search field, select, checkbox, radio group, switch, slider, toggle and toggle group (segmented control), tabs, table, badge (with `data-tone="success|warning|info|error"`), avatar, progress, skeleton, tooltip, dialog, alert dialog, sheet, pagination, dot pagination, table of contents, fade overflow, progressive blur, image gallery, success mark, sidebar, separator, textarea, media timeline and selection labels.
- **Subpaths**: chart; calendar, date range picker, time picker; text and element motion; like, clap, slosh slider, tilt card and grayscale stamps; `/blocks` adds GlassTabBar, MorphNav, ActionMorph and DataFlow.
- Not adopted: Heat map (a decorative canvas word demo, not a data heat map).

Every 1.0.0 and 0.1.0 export keeps its name and props. The [1.0.15 upgrade record](docs/compass-adoption.md#upgrade-to-1015) separates drop-in fixes from optional additions. Behaviour changes are listed in [the adoption record](docs/compass-adoption.md#changes-from-010).

## Where things are

- [Adoption record](docs/compass-adoption.md): mapping, what was changed in upstream code and why, compatibility, checks, history. Read it before the upstream [COMPASS guide](docs/compass.md).
- `upstream/1.0.15/`: current original registry payloads, URLs/SHA-256 and generated adoption lock. `scripts/adopt-upstream.mjs` regenerates the approved source with every adaptation named. `upstream/1.0.0/` and `upstream/0.1.0/` remain unchanged as history.
- Approved review: [261027 Compass 1.0.15 Update](https://drive.google.com/drive/folders/1ISjtxggJF1_06C2aK8cuJRmxSKjPUMDm), including its approval note. [1.0.0 review history](../../261019%20Compass%201.0%20Update/) and the `review/` folder (0.1.0) remain intact.
- `alex-infield-compass-augmentation-1.0.0.tgz` and `alex-infield-compass-augmentation-0.1.0.tgz` are kept unchanged for pinned apps and rollback. The complete 1.0.0 source/build-input checkpoint is [`upstream/1.0.0/alex-infield-compass-augmentation-1.0.0-source.tgz`](upstream/1.0.0/alex-infield-compass-augmentation-1.0.0-source.tgz); restore and verify it in Scratch before any source rollback.

## Working on the source

Use a host-local copy (never `node_modules` or builds in Drive): `npm ci --ignore-scripts`, `npm run verify:source`, `npm run build`, `npm run build:preview`, `npm run preview` (gallery on `127.0.0.1:4189`), then `npm pack`. A later COMPASS release is a deliberate, reviewed upgrade: download its payloads into `upstream/<version>/`, re-run the adopter, review, check and record it here.

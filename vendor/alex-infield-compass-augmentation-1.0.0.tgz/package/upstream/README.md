# Upstream COMPASS payloads

Original registry downloads, unchanged, with source URLs and SHA-256 in each `sources.json`.

- `1.0.0/` — current. `adoption-lock.json` lists the upstream and adopted hash of every file that `scripts/adopt-upstream.mjs` generates.
- `0.1.0/` — the first install (October 16, 2026), kept as history: payloads, the one-URL transport copy it needed, its source lock and the raw upstream stylesheet.
- `shadcn-css-source.json` — identity of the shadcn 4.21.0 variant CSS kept in `src/shadcn-variants.css`.

`npm run verify:source` checks all of these.

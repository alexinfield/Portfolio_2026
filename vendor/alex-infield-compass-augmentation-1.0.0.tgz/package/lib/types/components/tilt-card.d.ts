import "./tilt-card.css";
type TiltCardProps = {
    tilt?: number;
    corner?: number;
    shade?: number;
    width?: number;
    imageSrc?: string;
    label?: string;
};
export declare function TiltCard({ tilt, corner, shade, width, imageSrc, label, }?: TiltCardProps): import("react").JSX.Element;
export {};

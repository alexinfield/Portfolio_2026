import * as React from "react";
import { ThemeProvider as NextThemesProvider } from "next-themes";
declare function ThemeProvider({ children, enableThemeHotkey, ...props }: React.ComponentProps<typeof NextThemesProvider> & {
    enableThemeHotkey?: boolean;
}): React.JSX.Element;
export { ThemeProvider };

declare function Calendar({ selected, onSelect, language, today, }: {
    selected?: Date;
    onSelect: (date: Date | undefined) => void;
    language?: "ko" | "en";
    today?: Date;
}): import("react").JSX.Element;
export { Calendar };

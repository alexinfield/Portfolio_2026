import * as React from "react";
declare function Input({ className, type, controlSize, ...props }: React.ComponentProps<"input"> & {
    controlSize?: "default" | "sm";
}): React.JSX.Element;
export { Input };

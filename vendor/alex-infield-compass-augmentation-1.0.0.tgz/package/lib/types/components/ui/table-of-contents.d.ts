import { type ComponentProps } from "react";
type TocItem = {
    id: string;
    label: string;
    depth?: number;
};
type TableOfContentsProps = Omit<ComponentProps<"nav">, "children"> & {
    items: TocItem[];
    activeId?: string;
    onNavigate?: (id: string) => void;
};
declare function TableOfContents({ items, activeId, onNavigate, className, ...props }: TableOfContentsProps): import("react").JSX.Element;
export { TableOfContents };
export type { TocItem, TableOfContentsProps };

export declare function SuccessMark({ label }: {
    label?: string;
}): import("react").JSX.Element;

import { type DateRange } from "react-day-picker";
export declare function DateRangePicker({ range, onRangeChange, locale, size, maxDate, onApply, applyLabel, error }: {
    range?: DateRange;
    onRangeChange: (range: DateRange | undefined) => void;
    locale?: "ko" | "en";
    size?: "default" | "sm";
    maxDate?: Date;
    onApply?: (range: {
        from: Date;
        to: Date;
    }) => boolean | void;
    applyLabel?: string;
    error?: string;
}): import("react").JSX.Element;

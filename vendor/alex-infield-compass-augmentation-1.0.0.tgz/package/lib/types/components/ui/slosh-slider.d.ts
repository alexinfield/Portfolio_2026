export declare function SloshSlider({ label, defaultValue, onValueChange }?: {
    label?: string;
    defaultValue?: number;
    onValueChange?: (value: number) => void;
}): import("react").JSX.Element;

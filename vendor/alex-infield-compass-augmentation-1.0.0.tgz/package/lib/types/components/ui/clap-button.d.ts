export declare function ClapButton({ label, defaultCount, onClap, className }: {
    label?: string;
    defaultCount?: number;
    onClap?: () => void;
    className?: string;
}): import("react").JSX.Element;

import { type ReactNode } from "react";
export declare function FadeOverflow({ children, title }: {
    children: ReactNode;
    title?: string;
}): import("react").JSX.Element;

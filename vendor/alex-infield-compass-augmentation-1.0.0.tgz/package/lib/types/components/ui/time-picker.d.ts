type TimePickerProps = {
    value: string;
    onValueChange: (value: string) => void;
    label?: string;
    periodLabel?: string;
    hourLabel?: string;
    minuteLabel?: string;
    amLabel?: string;
    pmLabel?: string;
    minuteStep?: 1 | 5 | 10 | 15 | 30;
};
declare function TimePicker({ value, onValueChange, label, periodLabel, hourLabel, minuteLabel, amLabel, pmLabel, minuteStep, }: TimePickerProps): import("react").JSX.Element;
export { TimePicker };
export type { TimePickerProps };

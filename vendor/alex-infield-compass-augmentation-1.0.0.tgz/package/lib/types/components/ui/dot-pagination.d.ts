import type { ComponentProps } from "react";
import { Pagination } from "./pagination";
type DotPaginationProps = Omit<ComponentProps<typeof Pagination>, "children"> & {
    pageCount: number;
    page: number;
    onPageChange: (page: number) => void;
    getPageLabel?: (page: number) => string;
};
declare function DotPagination({ pageCount, page, onPageChange, getPageLabel, ...props }: DotPaginationProps): import("react").JSX.Element;
export { DotPagination };

export declare function ProgressiveBlur({ className, src }: {
    className?: string;
    src?: string;
}): import("react").JSX.Element;

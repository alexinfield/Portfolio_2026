export type GalleryPhoto = {
    src: string;
    width: number;
    height: number;
    alt: string;
    altKo?: string;
    crop?: {
        aspectRatio: number;
        position?: string;
    };
};
export type GalleryLayout = "grid" | "masonry" | "justified" | "thumbnail";
export declare function ImageGallery({ photos, layout, locale, }: {
    photos: GalleryPhoto[];
    layout: GalleryLayout;
    locale?: string;
}): import("react").JSX.Element | null;

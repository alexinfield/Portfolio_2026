import { type ReactNode } from "react";
import { type TargetAndTransition } from "motion/react";
export type ElementMotionVariant = "fade" | "slide" | "scale" | "pop" | "mask" | "blur" | "bounce";
export declare function elementMotionStates(variant: ElementMotionVariant, reduced?: boolean): {
    initial: TargetAndTransition;
    animate: TargetAndTransition;
    exit: TargetAndTransition;
} | {
    initial: {
        opacity: number;
    };
    animate: {
        opacity: number;
    };
    exit: {
        opacity: number;
    };
};
export declare function ElementMotion({ variant, visible, children, className, }: {
    variant: ElementMotionVariant;
    visible?: boolean;
    children: ReactNode;
    className?: string;
}): import("react").JSX.Element;

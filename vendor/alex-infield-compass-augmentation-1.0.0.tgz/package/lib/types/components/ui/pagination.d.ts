import * as React from "react";
import { Button } from "./button";
declare function Pagination({ className, ...props }: React.ComponentProps<"nav">): React.JSX.Element;
declare function PaginationContent({ className, ...props }: React.ComponentProps<"ul">): React.JSX.Element;
declare function PaginationItem({ ...props }: React.ComponentProps<"li">): React.JSX.Element;
type PaginationLinkProps = {
    isActive?: boolean;
} & Pick<React.ComponentProps<typeof Button>, "size"> & React.ComponentProps<"a">;
declare function PaginationLink({ className, isActive, size, ...props }: PaginationLinkProps): React.JSX.Element;
declare function PaginationPrevious({ className, text, compact, ...props }: React.ComponentProps<typeof PaginationLink> & {
    text?: string;
    compact?: boolean;
}): React.JSX.Element;
declare function PaginationNext({ className, text, compact, ...props }: React.ComponentProps<typeof PaginationLink> & {
    text?: string;
    compact?: boolean;
}): React.JSX.Element;
declare function PaginationEllipsis({ className, ...props }: React.ComponentProps<"span">): React.JSX.Element;
export { Pagination, PaginationContent, PaginationEllipsis, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious, };

export declare function LikeButton({ defaultLiked, onLikedChange, label, unlikeLabel, className, }: {
    defaultLiked?: boolean;
    onLikedChange?: (liked: boolean) => void;
    label?: string;
    unlikeLabel?: string;
    className?: string;
}): import("react").JSX.Element;

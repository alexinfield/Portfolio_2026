import { type ComponentProps } from "react";
import { Input } from "./input";
export declare function SearchField({ value, onValueChange, clearLabel, className, ...props }: Omit<ComponentProps<typeof Input>, "value" | "onChange" | "type" | "ref"> & {
    value: string;
    onValueChange: (value: string) => void;
    clearLabel?: string;
}): import("react").JSX.Element;

import type { ComponentProps } from "react";
export declare function Table({ className, density, ...props }: ComponentProps<"table"> & {
    density?: "default" | "compact";
}): import("react").JSX.Element;
export declare function TableHeader(props: ComponentProps<"thead">): import("react").JSX.Element;
export declare function TableBody(props: ComponentProps<"tbody">): import("react").JSX.Element;
export declare function TableRow({ className, ...props }: ComponentProps<"tr">): import("react").JSX.Element;
export declare function TableHead({ className, children, onSort, sortDirection, ...props }: ComponentProps<"th"> & {
    onSort?: () => void;
    sortDirection?: "none" | "ascending" | "descending";
}): import("react").JSX.Element;
export declare function TableCell({ className, ...props }: ComponentProps<"td">): import("react").JSX.Element;
export declare function TableCaption({ className, ...props }: ComponentProps<"caption">): import("react").JSX.Element;

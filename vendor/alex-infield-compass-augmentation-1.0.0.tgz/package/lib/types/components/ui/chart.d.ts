export type ChartDatum = {
    label: string;
    value: number;
    secondary?: number;
    [key: `series${number}`]: number | undefined;
};
export type ChartType = "bar" | "line" | "area" | "pie" | "donut" | "radar" | "radial";
export type ChartSeries = {
    key: "value" | "secondary" | `series${number}`;
    label: string;
    color?: string;
};
export type ChartOptions = {
    yAxisWidth?: number;
    yAxisAllowDecimals?: boolean;
    horizontal?: boolean;
    stacked?: boolean;
    normalized?: boolean;
    curve?: "linear" | "monotone" | "step";
    dots?: boolean;
    showLabels?: boolean;
    showLegend?: boolean;
    interactiveLegend?: boolean;
    gradient?: boolean;
    centerText?: boolean;
    radarGrid?: "polygon" | "circle";
    tooltipIndicator?: "dot" | "line" | "none";
};
export declare function ChartTooltipContent({ active, label, payload, indicator, locale, unit, }: {
    active?: boolean;
    label?: unknown;
    payload?: readonly {
        name?: unknown;
        value?: unknown;
        color?: string;
    }[];
    indicator?: "dot" | "line" | "none";
    locale?: string;
    unit?: string;
}): import("react").JSX.Element | null;
export declare function pieGeometry(width: number, height: number, donut: boolean): {
    cx: number;
    cy: number;
    outerRadius: number;
    innerRadius: number;
    paddingAngle: number;
    strokeWidth: number;
};
export declare function stackedBarRadius(item: ChartDatum | undefined, key: ChartSeries["key"], series: ChartSeries[], horizontal: boolean): [number, number, number, number];
type ChartPoint = {
    x: number;
    y: number;
};
type ChartScale = (value: unknown, options?: {
    position?: "middle";
}) => number | undefined;
export declare function chartPointerPosition(pointer: ChartPoint, bounds: {
    left: number;
    top: number;
    width: number;
    height: number;
}, chart: {
    width: number;
    height: number;
}): ChartPoint | undefined;
export declare function chartTooltipAnchor({ type, index, data, series, options, xScale, yScale, plot, sector, coordinate, }: {
    type: ChartType;
    index: number;
    data: ChartDatum[];
    series: ChartSeries[];
    options: ChartOptions;
    xScale?: ChartScale;
    yScale?: ChartScale;
    plot?: {
        x: number;
        y: number;
        width: number;
        height: number;
    };
    coordinate?: ChartPoint;
    sector?: {
        cx?: number;
        cy?: number;
        innerRadius?: number;
        outerRadius?: number;
        startAngle?: number;
        endAngle?: number;
    };
}): ChartPoint | undefined;
export declare function chartTooltipPosition(anchor: ChartPoint, size: {
    width: number;
    height: number;
}, chart: {
    width: number;
    height: number;
}, followPointer?: boolean): ChartPoint;
export declare function Chart({ data, type, title, valueLabel, emptyLabel, height, locale, className, series, options, unit, }: {
    data: ChartDatum[];
    type?: ChartType;
    title: string;
    valueLabel: string;
    emptyLabel: string;
    height?: number;
    locale?: string;
    className?: string;
    series?: ChartSeries[];
    options?: ChartOptions;
    unit?: string;
}): import("react").JSX.Element;
export {};

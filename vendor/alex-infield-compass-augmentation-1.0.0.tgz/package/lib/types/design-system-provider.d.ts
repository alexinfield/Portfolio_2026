import { type ComponentProps, type HTMLAttributes } from "react";
import { ThemeProvider } from "./components/theme-provider";
/**
 * The styling boundary. Everything COMPASS renders — including dialogs, menus, sheets,
 * tooltips and chart tooltips, which portal into this element — takes Alex's tokens from here.
 * Pass `theme` when the app already owns appearance; otherwise it follows the nearest
 * ThemeProvider (or light when there is none).
 */
export declare function DesignSystemBoundary({ theme, className, children, ...props }: HTMLAttributes<HTMLDivElement> & {
    theme?: "light" | "dark";
}): import("react").JSX.Element;
/**
 * Use once at an app root that has no theme owner yet. Defaults to dark (Alex's preference,
 * October 2026); pass defaultTheme="system" to follow the device, or "light". It also sets
 * class="dark" and data-theme on <html>, so page-level Alex tokens (tokens.css) follow along.
 * Under an existing theme owner, use DesignSystemBoundary alone.
 */
export declare function DesignSystemProvider({ children, ...props }: ComponentProps<typeof ThemeProvider>): import("react").JSX.Element;

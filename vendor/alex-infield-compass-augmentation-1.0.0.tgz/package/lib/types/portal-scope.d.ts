/** Portals inherit the same tokens, theme, and CSS boundary as their trigger. */
export declare const PortalScope: import("react").Context<HTMLElement | null | undefined>;
export declare function usePortalScope(): HTMLElement | null | undefined;

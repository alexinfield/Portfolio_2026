"use client";

import {useState, type ComponentProps, type HTMLAttributes} from "react";
import {useTheme} from "next-themes";
import {ThemeProvider} from "./components/theme-provider";
import {PortalScope} from "./portal-scope";

/**
 * The styling boundary. Everything COMPASS renders — including dialogs, menus, sheets,
 * tooltips and chart tooltips, which portal into this element — takes Alex's tokens from here.
 * Pass `theme` when the app already owns appearance; otherwise it follows the nearest
 * ThemeProvider (or light when there is none).
 */
export function DesignSystemBoundary({theme, className = "", children, ...props}:
  HTMLAttributes<HTMLDivElement> & {theme?: "light" | "dark"}) {
  const {resolvedTheme} = useTheme();
  const appearance = theme ?? (resolvedTheme === "dark" ? "dark" : "light");
  const [container, setContainer] = useState<HTMLDivElement | null>(null);
  return <PortalScope.Provider value={container}>
    <div {...props} ref={setContainer} data-alex-ui data-theme={appearance}
      data-density="compact" className={`compass-scope${appearance === "dark" ? " dark" : ""}${className ? ` ${className}` : ""}`}>
      {children}
    </div>
  </PortalScope.Provider>;
}

/**
 * Use once at an app root that has no theme owner yet. Defaults to dark (Alex's preference,
 * October 2026); pass defaultTheme="system" to follow the device, or "light". It also sets
 * class="dark" and data-theme on <html>, so page-level Alex tokens (tokens.css) follow along.
 * Under an existing theme owner, use DesignSystemBoundary alone.
 */
export function DesignSystemProvider({children, ...props}: ComponentProps<typeof ThemeProvider>) {
  return <ThemeProvider storageKey="alex-design-theme" defaultTheme="dark" attribute={["class", "data-theme"]} {...props}>
    <DesignSystemBoundary>{children}</DesignSystemBoundary>
  </ThemeProvider>;
}

import * as React from "react"
import { cn } from "cn"

import { Button } from "@/components/ui/button"

import { ArrowLeft, ArrowRight, Ellipsis } from "lucide-react"

function Pagination({ className, ...props }: React.ComponentProps<"nav">) {
  return (
    <nav
      role="navigation"
      aria-label="pagination"
      data-slot="pagination"
      className={cn("mx-auto flex w-full justify-center", className)}
      {...props}
    />
  )
}

function PaginationContent({
  className,
  ...props
}: React.ComponentProps<"ul">) {
  return (
    <ul
      data-slot="pagination-content"
      className={cn("flex items-center gap-0.5", className)}
      {...props}
    />
  )
}

function PaginationItem({ ...props }: React.ComponentProps<"li">) {
  return <li data-slot="pagination-item" {...props} />
}

type PaginationLinkProps = {
  isActive?: boolean
} & Pick<React.ComponentProps<typeof Button>, "size"> &
  React.ComponentProps<"a">

function PaginationLink({
  className,
  isActive,
  size = "icon",
  ...props
}: PaginationLinkProps) {
  return (
    <Button
      asChild
      variant="outline"
      size={size}
      className={cn(!isActive && "border-0", className)}
    >
      <a
        aria-current={isActive ? "page" : undefined}
        data-slot="pagination-link"
        data-active={isActive}
        {...props}
      />
    </Button>
  )
}

function PaginationPrevious({
  className,
  text = "Previous",
  compact = false,
  ...props
}: React.ComponentProps<typeof PaginationLink> & { text?: string; compact?: boolean }) {
  return (
    <PaginationLink
      aria-label="Go to previous page"
      size={compact ? "icon-sm" : "default"}
      className={cn(!compact && "pl-1.5!", className)}
      {...props}
    >
      <ArrowLeft strokeWidth={2} data-icon={compact ? undefined : "inline-start"} />
      {!compact && <span className="hidden sm:block">{text}</span>}
    </PaginationLink>
  )
}

function PaginationNext({
  className,
  text = "Next",
  compact = false,
  ...props
}: React.ComponentProps<typeof PaginationLink> & { text?: string; compact?: boolean }) {
  return (
    <PaginationLink
      aria-label="Go to next page"
      size={compact ? "icon-sm" : "default"}
      className={cn(!compact && "pr-1.5!", className)}
      {...props}
    >
      {!compact && <span className="hidden sm:block">{text}</span>}
      <ArrowRight strokeWidth={2} data-icon={compact ? undefined : "inline-end"} />
    </PaginationLink>
  )
}

function PaginationEllipsis({
  className,
  ...props
}: React.ComponentProps<"span">) {
  return (
    <span
      aria-hidden
      data-slot="pagination-ellipsis"
      className={cn(
        "flex size-8 items-center justify-center [&_svg:not([class*='size-'])]:size-4",
        className
      )}
      {...props}
    >
      <Ellipsis strokeWidth={2} />
      <span className="sr-only">More pages</span>
    </span>
  )
}

export {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
}

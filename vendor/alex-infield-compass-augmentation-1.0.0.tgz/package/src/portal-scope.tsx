import {createContext, useContext} from "react";

/** Portals inherit the same tokens, theme, and CSS boundary as their trigger. */
export const PortalScope = createContext<HTMLElement | null | undefined>(undefined);
export function usePortalScope() { return useContext(PortalScope); }

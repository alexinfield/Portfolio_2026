import "./alex-compass.css";

// Alex design system × COMPASS 1.0.0 — core kit. Heavier optional families live on subpaths:
// "/chart" (Recharts), "/date" (calendar and pickers), "/motion" and "/playful".
// Where an app already has an accepted Alex component (R05/R7 Button, Card, Input, Link,
// navigation, status), keep using it; these fill the gaps with the same tokens.
export {DesignSystemProvider, DesignSystemBoundary} from "./design-system-provider";
export {PortalScope, usePortalScope} from "./portal-scope";
export {ThemeProvider} from "./components/theme-provider";
// Appearance state for a Light / Dark / System control (same instance the provider uses).
export {useTheme} from "next-themes";

// Present in 0.1.0 (unchanged names).
export * from "./components/ui/dialog";
export * from "./components/ui/alert-dialog";
export * from "./components/ui/select";
export * from "./components/ui/sheet";
export * from "./components/ui/tabs";
export * from "./components/ui/toggle";
export * from "./components/ui/toggle-group";
export * from "./components/ui/slider";
export * from "./components/ui/progress";
export * from "./components/ui/badge";
export * from "./components/ui/avatar";
export * from "./components/ui/pagination";

// New in 1.0.0.
export * from "./components/ui/button";
export * from "./components/ui/card";
export * from "./components/ui/input";
export * from "./components/ui/checkbox";
export * from "./components/ui/radio-group";
export * from "./components/ui/switch";
export * from "./components/ui/search-field";
export * from "./components/ui/skeleton";
export * from "./components/ui/tooltip";
export * from "./components/ui/table";
export * from "./components/ui/table-of-contents";
export * from "./components/ui/dot-pagination";
export * from "./components/ui/fade-overflow";
export * from "./components/ui/progressive-blur";
export * from "./components/ui/image-gallery";
export * from "./components/ui/success-mark";

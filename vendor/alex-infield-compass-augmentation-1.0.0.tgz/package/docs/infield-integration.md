# Infield and Mission Control integration

Alex chose on October 16, 2026 to continue the Infield app in this design direction (Alex's style with COMPASS components). The Mission Control rebuild (October 2026) consumes the package through one wrapper module in its client, so a version change is a one-file swap there.

## Rules for the app owner

- The app's own source owner integrates and releases; this library does not change running services.
- Install the closed TGZ from this folder; keep the app's React (19.2.7 today) and package manager. Don't force peers or install a second copy.
- Import `@alex-infield/compass-augmentation/styles.css` once, **before** the app's stylesheet.
- The app owns appearance, so wrap it in `DesignSystemBoundary theme={resolved}`; dark is Alex's default.
- Keep the app's authenticated font route, accepted task-state colours and labels, and its server contracts (passkey, sessions, task revisions, conflicts, Undo). This is UI only.
- Avoid app class names that match Tailwind utilities (`.grid`, `.flex`, `.hidden` …) inside the boundary, or prefix them.

## Moving from 0.1.0 to 1.0.0

Read [Changes from 0.1.0](compass-adoption.md#changes-from-010). For Mission Control specifically: its tokens equal Alex's, so colours don't change; its `button { background: none; padding: 0 }` reset no longer strips COMPASS buttons (it did under 0.1.0); its hand-made switch, search field and skeleton can be replaced by the 1.0 components.

## Release checks

Build the app's production bundle, then check phone and desktop, light and dark, keyboard focus, dialogs and menus (they must open inside the boundary), enlarged text and safe areas on the real device. Record the package version and TGZ hash with the release.

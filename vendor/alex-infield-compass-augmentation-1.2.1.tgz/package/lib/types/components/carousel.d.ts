import * as React from "react";
import { Button } from "./ui/button";
import { DotPagination } from "./ui/dot-pagination";
import "./carousel.css";
type CarouselState = {
    index: number;
    count: number;
    label: string;
    inView: boolean;
    reduced: boolean;
    /** The motion layer is mounted. False in server markup, without JS and before hydration. */
    enhanced: boolean;
    /** `quiet` skips the live-region announcement (used when adopting a pre-hydration scroll). */
    goTo: (index: number, quiet?: boolean) => void;
    setCount: (count: number) => void;
    setEnhanced: (enhanced: boolean) => void;
    slides: React.RefObject<(HTMLElement | null)[]>;
    /** Render-time hints so server markup already has the right frame style. */
    seamless: boolean;
    peek: boolean;
};
type SlideState = {
    index: number;
    /** The slide on screen; only it is focusable and exposed to assistive technology. */
    active: boolean;
    /** The active slide or a direct neighbour: load its media eagerly. */
    near: boolean;
    /** The carousel is at least 20% on screen. */
    inView: boolean;
    /** The motion layer is mounted. Before that (server markup, no JS) every slide is reachable
     * in a native scroll list, so custom media should offer native controls. */
    enhanced: boolean;
};
declare function useCarousel(): CarouselState;
/** Slide state for custom media, for example an app's own deferred video component. */
declare function useCarouselSlide(): SlideState;
type CarouselProps = Omit<React.ComponentProps<"section">, "onChange"> & {
    /** Names the region, for example the project title: "<label>, carousel". */
    label: string;
    index?: number;
    defaultIndex?: number;
    onIndexChange?: (index: number) => void;
    /** Slide width as a share of the frame (default 1). Below 1 shows the neighbours, like App Store cards. CSS may set --carousel-slide instead. */
    slideSize?: number;
    /** Space between slides in px (default 8). 0 makes one seamless frame. CSS may set --carousel-gap instead. */
    gap?: number;
    /** Slide frame ratio, reserved before media loads (default 4 / 3). CSS may set --carousel-ratio instead. */
    aspectRatio?: number | string;
};
declare function Carousel({ label, index: controlled, defaultIndex, onIndexChange, slideSize, gap, aspectRatio, className, style, children, onKeyDown, ...props }: CarouselProps): React.JSX.Element;
/** The clipped frame and its moving track. Children are CarouselSlide elements. */
declare function CarouselContent({ className, children, ...props }: React.ComponentProps<"div">): React.JSX.Element;
type SlideProps = Omit<React.ComponentProps<"div">, "children"> & {
    children?: React.ReactNode | ((state: SlideState) => React.ReactNode);
};
declare function CarouselSlide({ className, children, ...props }: SlideProps): React.JSX.Element;
declare function CarouselControls({ className, ...props }: React.ComponentProps<"div">): React.JSX.Element;
type StepProps = React.ComponentProps<typeof Button>;
declare const CarouselPrevious: ({ className, onClick, ...props }: StepProps) => React.JSX.Element;
declare const CarouselNext: ({ className, onClick, ...props }: StepProps) => React.JSX.Element;
/** COMPASS DotPagination bound to the carousel. Prev/Next stay the 44 px equivalent control. */
declare function CarouselDots({ className, ...props }: Partial<React.ComponentProps<typeof DotPagination>>): React.JSX.Element | null;
type VideoProps = Omit<React.ComponentProps<"video">, "children"> & {
    /** Names the video in its button: "Pause video: <label>". */
    label: string;
};
/**
 * Inline, muted, looping preview video under the media contract: plays only while its slide is
 * active and the carousel is on screen, keeps an explicit Pause, starts static under reduced
 * motion (Play is allowed, without looping), and offers Play when autoplay is blocked.
 */
declare function CarouselVideo({ label, className, loop, onPlay, onPause, onError, ...props }: VideoProps): React.JSX.Element;
export { Carousel, CarouselContent, CarouselSlide, CarouselControls, CarouselPrevious, CarouselNext, CarouselDots, CarouselVideo, useCarousel, useCarouselSlide, };
export type { CarouselProps, SlideState as CarouselSlideState };

/**
 * COMPASS's layout spring (stiffness 500, mass 0.7; STYLE_GUIDE "Motion rules") at critical
 * damping: 37.4 instead of COMPASS's 40. Both have no overshoot from rest, but 40 is slightly
 * overdamped and only comes to rest after ~415 ms; critical damping rests in under 400 ms.
 */
export declare const SPRING: {
    stiffness: number;
    damping: number;
    mass: number;
};
/** At rest: within half a CSS pixel and slower than 20 px/s, the last step is a sub-pixel snap. */
export declare const atRest: (pos: number, vel: number, target: number) => boolean;
/** UIScrollView-style rubber band: resistance grows with distance and never passes `size`. */
export declare function band(over: number, size: number): number;
/** Advance the spring by `dt` seconds in 4 ms substeps. Returns [position, velocity]. */
export declare function spring(pos: number, vel: number, target: number, dt: number): [number, number];
/**
 * The slide to settle on after a gesture. `pos` is the on-screen scroll distance, `vel` px/s
 * (positive toward later slides). A flick (over 300 px/s) goes one slide in its direction, so a
 * flick back cancels; otherwise the nearest slide after a short 120 ms projection. One slide per
 * gesture, as in Photos.
 */
export declare function chooseSlide(pos: number, vel: number, step: number, from: number, count: number): number;
